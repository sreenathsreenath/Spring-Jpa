package infinite.EmployJdbcClient;

public enum Gender {
	
	MALE,FEMALE

}
